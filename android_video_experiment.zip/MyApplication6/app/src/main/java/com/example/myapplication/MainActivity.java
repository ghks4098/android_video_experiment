package com.example.myapplication;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.*;
import android.hardware.camera2.params.RggbChannelVector;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.util.Range;
import android.util.Size;
import android.util.Log;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "AndroidCameraApi";
    private Button takeVideoButton;
    private TextureView textureView;
    private CameraDevice cameraDevice;
    private CameraCaptureSession cameraCaptureSessions;
    private CaptureRequest.Builder captureRequestBuilder;
    private Size imageDimension;
    private MediaRecorder mediaRecorder;
    private boolean isRecordingVideo;

    private static final int REQUEST_CAMERA_PERMISSION = 200;

    private CameraDevice.StateCallback stateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(@NonNull CameraDevice camera) {
            cameraDevice = camera;
            createCameraPreview();
        }

        @Override
        public void onDisconnected(@NonNull CameraDevice camera) {
            cameraDevice.close();
        }

        @Override
        public void onError(@NonNull CameraDevice camera, int error) {
            cameraDevice.close();
            cameraDevice = null;
        }
    };
    final CameraCaptureSession.CaptureCallback captureCallbackListener = new CameraCaptureSession.CaptureCallback() {
        @Override
        public void onCaptureCompleted(@NonNull CameraCaptureSession session,
                                       @NonNull CaptureRequest request,
                                       @NonNull TotalCaptureResult result) {
            super.onCaptureCompleted(session, request, result);
            createCameraPreview();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textureView = (TextureView) findViewById(R.id.textureView);
        assert textureView != null;
        textureView.setSurfaceTextureListener(textureListener);
        takeVideoButton = (Button) findViewById(R.id.btnRecord);
        assert takeVideoButton != null;

        // 비디오 녹화 버튼 이벤트 처리
        takeVideoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRecordingVideo) {
                    // 녹화 중지
                    stopRecordingVideo();
                } else {
                    // 녹화 시작
                    startRecordingVideo();
                }
            }
        });
    }

    private void startRecordingVideo() {
        if (cameraDevice == null || !textureView.isAvailable() || imageDimension == null) {
            Log.e(TAG, "카메라 설정이 완료되지 않았습니다.");
            return;
        }
        try {
            closeCameraCaptureSession();
            setUpMediaRecorder();

            SurfaceTexture texture = textureView.getSurfaceTexture();
            assert texture != null;
            texture.setDefaultBufferSize(imageDimension.getWidth(), imageDimension.getHeight());

            captureRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
            List<Surface> surfaces = new ArrayList<>();

            // 미리보기 Surface 설정
            Surface previewSurface = new Surface(texture);
            surfaces.add(previewSurface);
            captureRequestBuilder.addTarget(previewSurface);

            // MediaRecorder Surface 설정
            Surface recorderSurface = mediaRecorder.getSurface();
            surfaces.add(recorderSurface);
            captureRequestBuilder.addTarget(recorderSurface);

            // ISO와 AWB를 자동으로 설정
            captureRequestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON);
            captureRequestBuilder.set(CaptureRequest.CONTROL_AWB_MODE, CameraMetadata.CONTROL_AWB_MODE_AUTO);

            int fpsrange_c = 24;
            captureRequestBuilder.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, new Range<>(fpsrange_c, fpsrange_c));
            captureRequestBuilder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, 1000000000L / fpsrange_c);

            CameraCaptureSession.CaptureCallback captureCallback = new CameraCaptureSession.CaptureCallback() {
                @Override
                public void onCaptureCompleted(@NonNull CameraCaptureSession session,
                                               @NonNull CaptureRequest request,
                                               @NonNull TotalCaptureResult result) {
                    super.onCaptureCompleted(session, request, result);

                    // 현재 ISO 값과 화이트 밸런스 값 읽기
                    final Integer isoValue = result.get(CaptureResult.SENSOR_SENSITIVITY);
                    final RggbChannelVector wbGains = result.get(CaptureResult.COLOR_CORRECTION_GAINS);

                    // ISO 값과 화이트 밸런스 값을 로그로 출력
                    Log.d("CameraInfo", "ISO 값: " + (isoValue != null ? isoValue.toString() : "null"));
                    Log.d("CameraInfo", "화이트 밸런스 값: " + (wbGains != null ? wbGains.toString() : "null"));

                    if (isoValue != null && wbGains != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                // AE와 AWB를 고정 모드로 변경
                                captureRequestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF);
                                captureRequestBuilder.set(CaptureRequest.CONTROL_AWB_MODE, CameraMetadata.CONTROL_AWB_MODE_OFF);

                                // 읽어온 ISO 값으로 설정
                                captureRequestBuilder.set(CaptureRequest.SENSOR_SENSITIVITY, isoValue);

                                // 화이트 밸런스 게인 설정 (예제로는 읽어온 값을 그대로 사용)
                                captureRequestBuilder.set(CaptureRequest.COLOR_CORRECTION_GAINS, wbGains);

                                // 다른 설정들을 추가
                                int fpsrange_c = 24;
                                captureRequestBuilder.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, new Range<>(fpsrange_c, fpsrange_c));
                                captureRequestBuilder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, 1000000000L / fpsrange_c);

                                // 새로운 설정으로 캡처 요청을 업데이트하고 발송
                                // 예: session.capture(...) 또는 session.setRepeatingRequest(...)
                            }
                        }, 3000); // 3초 대기
                    }
                }
            };



            cameraDevice.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
                    cameraCaptureSessions = cameraCaptureSession;
                    updatePreview();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            isRecordingVideo = true;
                            takeVideoButton.setText("녹화 중지");
                            mediaRecorder.start();
                        }
                    });
                }

                @Override
                public void onConfigureFailed(@NonNull CameraCaptureSession cameraCaptureSession) {
                    Toast.makeText(MainActivity.this, "카메라 구성 실패", Toast.LENGTH_SHORT).show();
                }
            }, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setUpMediaRecorder() throws IOException {
        mediaRecorder = new MediaRecorder(); // MediaRecorder 인스턴스 생성

        mediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        String filePath = "/storage/emulated/0/DCIM/LHT_24_1100.avi"; //getFilesDir() + "/rppg.mp4"; // 파일 저장 경로 설정
        mediaRecorder.setOutputFile(filePath);
        mediaRecorder.setVideoEncodingBitRate(10000000);
        mediaRecorder.setVideoFrameRate(30);
        mediaRecorder.setVideoSize(imageDimension.getWidth(), imageDimension.getHeight());
        mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);

        mediaRecorder.prepare(); // MediaRecorder 준비
    }


    private void updatePreview() {
        if (cameraDevice == null) {
            Log.e(TAG, "updatePreview error, 카메라 디바이스가 null입니다.");
            return;
        }

        captureRequestBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);

        try {
            cameraCaptureSessions.setRepeatingRequest(captureRequestBuilder.build(), null, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void closeCameraCaptureSession() {
        if (cameraCaptureSessions != null) {
            cameraCaptureSessions.close();
            cameraCaptureSessions = null;
        }
    }


    private void stopRecordingVideo() {
        // 녹화 중지
        mediaRecorder.stop();
        mediaRecorder.reset();

        // 녹화 상태 업데이트
        isRecordingVideo = false;
        takeVideoButton.setText("녹화 시작");

        // 녹화가 끝난 후에도 카메라 미리보기를 계속 표시
        createCameraPreview();
    }


    TextureView.SurfaceTextureListener textureListener = new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            openCamera();
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
            // Transform your image captured size according to the surface width and height
        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return false;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {
        }
    };

    private void openCamera() {
        CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        Log.e(TAG, "is camera open");
        try {
            String cameraId = manager.getCameraIdList()[0];
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            assert map != null;
            imageDimension = map.getOutputSizes(SurfaceTexture.class)[0];
            //Add permission for camera and let user grant the permission
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, REQUEST_CAMERA_PERMISSION);
                return;
            }
            manager.openCamera(cameraId, stateCallback, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
        Log.e(TAG, "openCamera X");
    }

    protected void createCameraPreview() {
        try {
            SurfaceTexture texture = textureView.getSurfaceTexture();
            assert texture != null;
            texture.setDefaultBufferSize(imageDimension.getWidth(), imageDimension.getHeight());
            Surface surface = new Surface(texture);
            captureRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            captureRequestBuilder.addTarget(surface);

            //Range<Integer> fpsRange = new Range<>(30, 30); // 예: 30fps 고정
            //captureRequestBuilder.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fpsRange);

            int fpsrange_c = 24;
            captureRequestBuilder.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, new Range<>(fpsrange_c, fpsrange_c));
            captureRequestBuilder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, 1000000000L / fpsrange_c);

            cameraDevice.createCaptureSession(Arrays.asList(surface), new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
                    // 카메라가 이미 닫혔을 경우
                    if (null == cameraDevice) {
                        return;
                    }
                    // 세션 준비가 완료되면 미리보기를 시작합니다.
                    cameraCaptureSessions = cameraCaptureSession;
                    updatePreview();
                }

                @Override
                public void onConfigureFailed(@NonNull CameraCaptureSession cameraCaptureSession) {
                    Toast.makeText(MainActivity.this, "Configuration change", Toast.LENGTH_SHORT).show();
                }
            }, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

}
